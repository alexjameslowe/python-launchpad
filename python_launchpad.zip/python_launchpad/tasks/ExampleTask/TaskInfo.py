
def validateArgs(argsObj):
  if(argsObj["show_this"] == "99"):
    return 'No you cant pass in 99 here.'
  
  return None


info = {

  #This is the argument which will select this task.
  'taskArg':'example_task',

  #This is the name of the task to run. Note that there must be a Task.py and 
  #a Monitor.py file in the task folder.
  'taskName':'ExampleTask',

  #Is this a single background task or is it a composite of several tasks?
  'composite':False,

  # A validator function to look at all the arguments
  'validator':validateArgs,

  # These are listings for threadsafe-variables that can be written and read 
  # by the task and the monitor. (You could write from the monitor someday when
  # we start doing user input.) 
  # It's self explanatory. The init is the value it gets inited with.
  #
  # There's three string for the behavior field.
  #
  #    die: the variable will only remain during the run of the task 
  #         and be removed after
  #
  #    output: the variable will be available for the monitor to read 
  #            even when the task is finished
  #
  #    persist: the variable will persist
  #
  # The default ones are RUNNING ERROR STEP WARNING GRACEFUL_EXIT PROCESS
  'vars':[],
  #'vars:['
  #  { 'name':'myVar', 'init':0, 'behavior':'die'}
  #  ...
  #  ...
  #  ...
  
  
  #Here are the other arguments that will be present in the command-line.
  'args': [
      
    #This is a flag-only arg "-test-arg". It just comes through as "1" if present in the 
    #command arguments.
    {
      'name':'test_arg',
      'help':'This is a test flag-only argument',
      'flag':True
    },

    # Here's another one and this one takes the same parameters as the add_argument function.
    # e.g. help='Get version info', default="0", const="1", nargs='?'
    # Two things to note:
    #
    # 1. the 'required' option is not present. Required is always going to be false. If we have 
    # a CLI with mutliple different modes and schemas for the arguments, then they really all have
    # to be optional and we have to enforce requiredness through other means.
    #  
    # 2. We have the name field, which is the dash_delimited version of the argument, 
    # i.e., show_this -> -show-this on the command line.
    #
    # 3. type is optional. it will be typed to these. If json, it will be turned into an object
    # 4. validator is optional. If present, it will apply a validation function to the typed argument value.
    #    The validator will return a string if there's a problem, else, None.
    { 
      'name':'show_this',
      'help':'Get the information', 
      'default':None,
      'type':'int', #int, float, str, json, yyyy-mm-dd
      'validator': lambda showThis : 'Cant be greater or equal to 99' if showThis >= 99 else None 
    }

  ],

  # The validator. An argument that takes the parsed args object as the single
  # argument and does validation. All of the arguments have to be optional for reasons
  # stated above, and because of that, we have to do validation manually. If there's
  # something wrong with the arguments, then the validator's job is to return
  # an error message. A return value of None will indicate that nothing is wrong.
  'validator': validateArgs

}